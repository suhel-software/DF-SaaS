# dcl_employee_id_generator/__init__.py
from . import models
